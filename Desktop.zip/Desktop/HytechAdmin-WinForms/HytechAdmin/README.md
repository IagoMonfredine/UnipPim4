# HYTECH Admin — Painel Desktop (Windows Forms)

Base desktop em **C# / Windows Forms (.NET 8)**, focada **exclusivamente no Admin**,
construída a partir da identidade visual e das funcionalidades administrativas do
HTML de referência (`Interface_Hytech_18V`).

## Telas implementadas

| Tela | Descrição |
|---|---|
| **Gerenciar Usuários** | Listagem com busca e filtros (perfil/status), criar, editar, ativar/inativar e excluir usuários (aluno, professor, administrador). |
| **Gerenciar Conteúdos** | Listagem com busca e filtros (tipo/status) de textos explicativos e questões, visualização em modal e remoção. |
| **Config** | Parâmetros de gamificação (chaves concedidas por questão fácil/média/difícil e por certificado emitido). |
| **Plataforma** | Cards de métricas gerais, distribuição de perfis de usuários (barras) e log do sistema. |

A navegação é feita por uma barra lateral fixa (sidebar), com visual simplificado
(paleta roxo/amarelo da marca), priorizando praticidade: grids com ações diretas
em botão, filtros simples, modais objetivos para criar/editar/visualizar.

## Estrutura do projeto

```
HytechAdmin/
├── HytechAdmin.sln
└── HytechAdmin/
    ├── Program.cs                  # Entry point
    ├── Forms/
    │   ├── MainForm.cs             # Janela principal (sidebar + troca de telas)
    │   ├── UsuarioEditForm.cs      # Modal de criar/editar usuário
    │   └── ConteudoViewForm.cs     # Modal de visualização de conteúdo
    ├── Controls/
    │   ├── UsuariosControl.cs      # Tela "Gerenciar Usuários"
    │   ├── ConteudosControl.cs     # Tela "Gerenciar Conteúdos"
    │   ├── ConfigControl.cs        # Tela "Config"
    │   └── PlataformaControl.cs    # Tela "Plataforma"
    ├── Models/
    │   ├── Usuario.cs
    │   ├── ConteudoItem.cs
    │   ├── LogEntry.cs
    │   └── ConfiguracaoPlataforma.cs
    ├── Services/                   # Camada de acesso a dados (ver seção abaixo)
    │   ├── IUsuarioService.cs      / UsuarioServiceMock.cs
    │   ├── IConteudoService.cs     / ConteudoServiceMock.cs
    │   └── IPlataformaService.cs   / PlataformaServiceMock.cs
    └── UI/
        └── Theme.cs                # Cores, fontes e fábricas de controles padronizados
```

## Como abrir e rodar

1. Requer **Visual Studio 2022** (ou superior) com a carga de trabalho
   **".NET desktop development"**, e o **.NET 8 SDK**.
2. Abra `HytechAdmin.sln` (ou a pasta do projeto) no Visual Studio.
3. Defina `HytechAdmin` como projeto de inicialização e pressione **F5**.

> O projeto usa apenas o SDK do .NET (não depende de designer `.Designer.cs`);
> todas as telas são montadas em código, o que facilita revisão e versionamento.

## Integração futura com API e Banco de Dados

O projeto já foi estruturado pensando na próxima etapa (API + BD). Toda a
"leitura e escrita de dados" passa por três **interfaces** em `Services/`:

- `IUsuarioService`
- `IConteudoService`
- `IPlataformaService`

Hoje, o `MainForm` instancia as versões **mock** (em memória):

```csharp
private readonly IUsuarioService _usuarioService = new UsuarioServiceMock();
private readonly IConteudoService _conteudoService = new ConteudoServiceMock();
private readonly IPlataformaService _plataformaService = new PlataformaServiceMock();
```

Quando a API estiver pronta, basta:

1. Criar `UsuarioServiceApi : IUsuarioService` (e equivalentes para os outros dois),
   implementando cada método com chamadas HTTP (`HttpClient`) para a API,
   ou diretamente com Entity Framework caso o desktop acesse o BD sem API intermediária.
2. Trocar a instanciação no `MainForm` (ex.: `new UsuarioServiceApi(httpClient)`).
3. **Nenhuma tela precisa ser alterada** — todas dependem apenas das interfaces.

Sugestão de próximos passos técnicos:
- Tornar os métodos das interfaces `async`/`Task<...>` ao integrar com a API real.
- Adicionar tela de login (autenticação do Admin) antes de abrir o `MainForm`.
- Adicionar tratamento de erros de rede/timeout nas implementações reais dos serviços.

## Observações de design

- Todas as cores e fontes ficam centralizadas em `UI/Theme.cs`, facilitando ajustes
  finos de identidade visual sem precisar caçar valores espalhados pelo código.
- Os dados de exemplo nos serviços mock replicam os mesmos usuários/conteúdos
  usados no protótipo HTML, para facilitar a comparação visual/funcional.
